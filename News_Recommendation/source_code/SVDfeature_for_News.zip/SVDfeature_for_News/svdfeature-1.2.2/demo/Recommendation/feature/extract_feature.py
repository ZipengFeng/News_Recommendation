#-*- coding: utf-8 -*-
'''
@author Gus
'''

import jieba
import jieba.analyse
import time
import random
import numpy as np
random.seed(2017)
import json

def datetime_timestamp(dt):
     #dt为字符串
     #中间过程，一般都需要将字符串转化为时间数组
     time.strptime(dt, '%Y-%m-%d %H:%M:%S')
     ## time.struct_time(tm_year=2012, tm_mon=3, tm_mday=28, tm_hour=6, tm_min=53, tm_sec=40, tm_wday=2, tm_yday=88, tm_isdst=-1)
     #将"2012-03-28 06:53:40"转化为时间戳
     s = time.mktime(time.strptime(dt, '%Y-%m-%d %H:%M:%S'))
     return int(s)

def get_newsdict(path, topk):     #construct a dictionary with news released before 20th, that's training set
    clickdata_file = open(path, 'r')
    news_wordset = set([])	#news dictionary containing all keywords computed with TFIDF 
    news_itemfreq = {}  	#record the the click numbers of each news
    newsID_index = {}

    userID_train = set([])	#user id of training set
    userID_all = set([]) 	#user id of total dataset
    newsID_all = set([])
    i = 1
    train_samples = 0
    for line in clickdata_file.readlines():
        line = line.strip().split('\t')
        surf_time = int(line[2])
	userID_all.add(line[0])			#user ID saved as type of string
	newsID_all.add(line[1])						
        if  surf_time >= 1393603200 and surf_time < 1395331200:   #first one is 2014/3/01, second one is 2014/3/21
            print 'processing %d news...'%i
            i += 1
            userID_train.add(line[0])
	    newsID = line[1]					#news ID saved as type of string
	    if news_itemfreq.has_key(newsID):			#len(newsID) in training set is 4802, while in total set is 6183.		
		news_itemfreq[newsID]+=1
	    else: news_itemfreq[newsID]=1
	    train_samples += 1
            news_title = line[-3]
            news_contents = line[-2]
            news_words =  news_title+' '+news_contents 
            keywords = list(jieba.analyse.extract_tags(news_words, topK=topk))
            news_wordset = news_wordset.union(set(keywords))
    word_dict = {}			#create a keyword-index dictionary				
    userid_dict = {}			#create a userID-index dictionary
    index = 0
    for id in userID_all:
	userid_dict[id]=index
	index += 1
    index = 0
    for word in news_wordset:
        word_dict[word] = index
        index += 1
    index = 0
    for news in newsID_all:
        newsID_index[news] = index
        index += 1
    clickdata_file.close()
    left_userID = userID_all - userID_train						#num of left userid is 762. That means there are 762 users who didn't show in training set.
    return word_dict, userid_dict, left_userID, news_itemfreq, newsID_index, train_samples			#word_dict==26170, userid_dict is based on total dataset, left_userID is users in test dataset but not in train dataset

def create_user_feature(click_data_path, user_ID_dict_path, word_dict_path, output_path, left_userID, freq_news, topk):
    click_data = open(click_data_path, 'r')
    with open(user_ID_dict_path, 'r') as f:
	user_ID_dict = json.load(fp=f)
    with open(word_dict_path, 'r') as f:
	word_dict = json.load(fp=f)


    freqNewsKeywords = {}

    user_feature_dict = {}
    i = 0
    for line in click_data.readlines():
	print 'creating user feature %d...'%i
	i+=1
	line = line.strip().split('\t')
	if int(line[2]) >= 1393603200 and int(line[2]) < 1395331200:
	    userID = user_ID_dict[line[0]]
            newsID = line[1]
	    keywords = list(jieba.analyse.extract_tags(line[-3]+' '+line[-2], topK=topk))
	
            if freq_news.has_key(newsID):
		freqNewsKeywords[newsID]=keywords 
	
	    if user_feature_dict.has_key(userID):
	        for word in keywords:
	            user_feature_dict[userID].add(word_dict[word])
	    else: 
	        user_feature_dict[userID]=set([])
	        for word in keywords:
	            user_feature_dict[userID].add(word_dict[word])



    for user in left_userID:
	user_feature_dict[user_ID_dict[user]]=set([])	
	print user
	for newsID in freq_news:
	    
	    for word in freqNewsKeywords[newsID]:
		user_feature_dict[user_ID_dict[user]].add(word_dict[word])
		
            
    for key in user_feature_dict:
	user_feature_dict[key] = list(user_feature_dict[key])

    with open(output_path, 'w') as f:
        json.dump(user_feature_dict, f)
    return user_feature_dict
    
def create_feature(datapath, train_path, test_path, word_dict=None, userID_dict=None, left_userID=None, news_itemfreq=None, newsID_index=None, train_samples=None, user_feature_dict=None, is_add_time = False):
    '''
	create a feature file with format of each line is: userID newsID click_or_not num_of_globalfeature num_of_userfeature num_of_itemfeature [globalfeature] userfeature itemfeature...

    '''

    if word_dict == None or userID_dict==None or news_itemfreq==None or newsID_index==None or train_samples==None:
    	word_dict, userID_dict, left_userID, news_itemfreq, newsID_index, train_samples = get_newsdict(datapath, 20)
	with open('./word_dict.json','w') as f:
	    json.dump(word_dict, f,encoding='utf-8')
	with open('./userid_dict.json','w') as f:
	    json.dump(userID_dict, f)
	with open('./left_userid.txt','w') as f:
	    for i in left_userID:
	    	f.write(str(userID_dict[i])+'\n')
	with open('./news_itemfreq.json','w') as f:
	    json.dump(news_itemfreq,f)
	with open('./newsID_index.json','w') as f:
	    json.dump(newsID_index, f)
	with open('./train_num.txt','w') as f:
	    f.write(str(train_samples))
    
    
    len_itemfeature = len(word_dict)		#the length of word feature vector of each news
    clickdata_file = open(datapath, 'r') 
    output_trainfeature = open(train_path,'w')	#the file containing train feature
    output_testfeature = open(test_path,'w')	#the file containing test feature
    num = 1					#recording the num of features generated 

    freq_news = news_itemfreq.copy()		#preserve the only frequent news with frequence bigger than non-personalized parameter
    for item in news_itemfreq:
	if news_itemfreq[item] <1000:		#if one news was read for more than 1000 times, then it was kept as frequent news. There are 10 news here.
		freq_news.pop(item)
    del news_itemfreq
    
    user_feature_dict = create_user_feature(datapath, './userid_dict.json', './word_dict.json', './user_feature_dict.json', left_userID, freq_news,20)

    freqNewsKeywords = {}				#records the keywords of each hot news
    test_newsID2Keywords = {}
    test_userID = set([])
    for news in clickdata_file.readlines():	#start to generate training features and testing features
        print 'generating %d feature...'%num
	
        num += 1
        line = news.strip().split('\t')
        user_id = userID_dict[line[0]]			#userID_dict is based on total dataset
        keywords = list(jieba.analyse.extract_tags(line[-3]+' '+line[-2],20))	#extracts keywords with news title and contents
        surf_time = int(line[2])
	newsID = line[1]				#raw newsID, not index here

	
        if freq_news.has_key(newsID):
		freqNewsKeywords[newsID]=keywords    
	


        if  surf_time >= 1393603200 and surf_time < 1395331200:   #between 03/01-03/20
            if is_add_time:
        	news_time_cut = list(jieba.cut(line[-1]))
        	news_time = 1393603200 if len(news_time_cut)<9 else datetime_timestamp(str('%s-%s-%s %s:%s:00'%(news_time_cut[0],news_time_cut[2],news_time_cut[4],news_time_cut[6],news_time_cut[8])))

                surftime_bin = (surf_time-1393603200)/86400
                newstime_bin = (news_time-1393603200)/86400 if abs((news_time-1393603200)/86400)<30 else 30
                output_trainfeature.write(str(user_id)+'\t'+newsID+'\t'+'1\t1\t1\t'+str(len(keywords)+1)+'\t'+str(surftime_bin)+':1\t'+str(user_id)+':1')
                for word in keywords:
                    output_trainfeature.write('\t'+str(word_dict[word])+':1')
                output_trainfeature.write('\t'+str(abs(newstime_bin)+len_itemfeature)+':'+str(1)+'\n')   #if newstime < 03/01, feature val is -1. otherwise is 1
            else:
		num_of_userfeature = len(user_feature_dict[user_id])
                output_trainfeature.write(str(user_id)+'\t'+newsID+'\t'+'1\t0\t'+str(num_of_userfeature)+'\t'+str(len(keywords)))
		for fea_index in user_feature_dict[user_id]:
		    output_trainfeature.write('\t'+str(fea_index)+':1')
                for word in keywords:
                    output_trainfeature.write('\t'+str(word_dict[word])+':1')
                output_trainfeature.write('\n')
        else:    #after 03/20, for test
            if is_add_time:
		test_newsID2Keywords[newsID] = keywords
		test_userID.add(user_id)
        	news_time_cut = list(jieba.cut(line[-1]))
        	news_time = 1393603200 if len(news_time_cut)<9 else datetime_timestamp(str('%s-%s-%s %s:%s:00'%(news_time_cut[0],news_time_cut[2],news_time_cut[4],news_time_cut[6],news_time_cut[8])))
                surftime_bin = (surf_time-1393603200)/86400
                newstime_bin = (news_time-1393603200)/86400 if abs((news_time-1393603200)/86400)<30 else 30
		feature_num = 0
                for word in keywords:
		    if word_dict.has_key(word):
                    	feature_num += 1
                output_testfeature.write(str(user_id)+'\t'+newsID+'\t'+'1\t1\t1\t'+str(feature_num+1)+'\t'+str(surftime_bin)+':1\t'+str(user_id)+':1')
                for word in keywords:
		    if word_dict.has_key(word):
                    	output_testfeature.write('\t'+str(word_dict[word])+':1')
                output_testfeature.write('\t'+str(abs(newstime_bin)+len_itemfeature)+':'+str(1)+'\n')   #if newstime < 03/01, feature val is -1. otherwise is 1
            else:
		test_newsID2Keywords[newsID] = keywords
		test_userID.add(user_id)
		num_of_userfeature = len(user_feature_dict[user_id])
		feature_num = 0
                for word in keywords:
		    if word_dict.has_key(word):
                    	feature_num += 1
                output_testfeature.write(str(user_id)+'\t'+newsID+'\t'+'1\t0\t'+str(num_of_userfeature)+'\t'+str(feature_num))
		for fea_index in user_feature_dict[user_id]:
		    output_testfeature.write('\t'+str(fea_index)+':1')
                for word in keywords:
		    if word_dict.has_key(word):
                    	output_testfeature.write('\t'+str(word_dict[word])+':1')
                output_testfeature.write('\n')


    with open('./test_newsID2keywords.json','w') as f:
	json.dump(test_newsID2Keywords, f)
    with open('./test_userID.txt','w') as f:
	for i in test_userID:
	    f.write(str(i)+'\n')
    for user in left_userID:	
	for newsID in freq_news:
	    output_trainfeature.write(str(userID_dict[user])+'\t'+newsID+'\t'+'1\t0\t'+str(len(user_feature_dict[userID_dict[user]]))+'\t'+str(len(freqNewsKeywords[newsID])))	#no time feature 
	    for fea_index in user_feature_dict[userID_dict[user]]:
		output_trainfeature.write('\t'+str(fea_index)+':1')
	    for word in freqNewsKeywords[newsID]:
		output_trainfeature.write('\t'+str(word_dict[word])+':1')
            output_trainfeature.write('\n')

'''
    feature_num = 0
    for newsID in freq_news:
	for word in freqNewsKeywords[newsID]:
	    if word_dict.has_key(word):
		feature_num += 1

    for user in left_userID:
	output_trainfeature.write('1\t0\t1\t'+str(feature_num)+'\t'+str(userID_dict[user])+':1\t')
	for newsID in freq_news:
	    for word in freqNewsKeywords[newsID]:
		output_trainfeature.write(str(word_dict[word])+':1\t')
        output_trainfeature.write('\n')
'''
	    
def add_userID_firstcol(feature_path, output_path):		#add userID in the first column
    output_feature = open(output_path, 'w')
    with open(feature_path,'r') as f:
	i = 1
	for line in f.readlines():
	    print 'transforming %d line'%i
	    i += 1
	    if line.strip().split('\t')[1]=='0':
		userID = (line.strip().split('\t')[4]).split(':')[0]
	    else:
	    	userID = (line.strip().split('\t')[5]).split(':')[0]
	    output_feature.writelines(userID+'\t'+line)
	
        
if __name__ == '__main__':
    import sys
    datapath=sys.argv[1]
    trainfea_path=sys.argv[2]
    testfea_path = sys.argv[3]
    create_feature(datapath,trainfea_path,testfea_path,   is_add_time=False)    
    #add_userID_firstcol('./train_feature.txt','./train_feature_withuserid.txt')  word_dict=word_dict, userID_dict=userid, left_userID=left_userid, news_itemfreq=news_itemfreq, newsID_index=newsID_index, train_samples=train_samples, user_feature_dict = user_feature_dict, 
        
        
        
    
    
    
    
    
    
    
