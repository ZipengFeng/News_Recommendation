import random
import sys
import json
random.seed(2017)

def create_testfeature(test_userIDpath, test_news2keyword_path, word_dict_path, user_feature_path, output_testfeature):
    test_userIDfile = open(test_userIDpath,'r')
    test_userID=[line.strip() for line in test_userIDfile.readlines()]
    with open(test_news2keyword_path, 'r') as f:
	test_news2keyword = json.load(fp=f)
    with open(word_dict_path, 'r') as f:
	word_dict = json.load(fp=f)
    with open(user_feature_path, 'r') as f:
	user_feature_dict = json.load(fp=f)

    test_feature = open(output_testfeature,'w')
    num = 1
    for user in test_userID:

	for news in test_news2keyword:
	    print 'generating %d line...'%num
	    num+=1
	    
	    feature_num = 0
	    for word in test_news2keyword[news]:
		if word_dict.has_key(word):
		    feature_num +=1
		    
	    test_feature.write('1\t0\t'+str(len(user_feature_dict[user]))+'\t'+str(feature_num))

	    for fea_index in user_feature_dict[user]:
		test_feature.write('\t'+str(fea_index)+':1')

	    for word in test_news2keyword[news]:
		if word_dict.has_key(word):
		    
		    test_feature.write('\t'+str(word_dict[word])+':1')
	    test_feature.write('\n')



if __name__ == '__main__':
    test_userIDpath = './test_userID.txt'
    test_news2keyword_path = './test_newsID2keywords.json'
    word_dict_path = './word_dict.json'
    #output_testfeature = './test_feature.base'
    user_feature_path = './user_feature_dict.json'
    output_testfeature = sys.argv[1]
    create_testfeature(test_userIDpath, test_news2keyword_path, word_dict_path, user_feature_path, output_testfeature)
