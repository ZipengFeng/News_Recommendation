#shuffle and sample negative samples
python feature/extract_feature.py feature/user_click_data.txt ./ua.base feature/test_feature_groundtruth.txt
python feature/create_testfeature.py ./test_feature.base
../../tools/svdpp_randorder ua.base ua.base.order
../../tools/line_reorder ua.base ua.base.order ua.base.group 

python sample_neg.py ua.base.group ua.base.group.3N 3
python base_to_feature.py ua.base.group.3N ua.base.group.3NN

#../../tools/svdpp_randorder ua.test ua.test.order
#../../tools/line_reorder ua.test ua.test.order ua.test.group 

#python sample_neg.py ua.test.group ua.test.group.3N 0
#python base_to_feature.py ua.test.group.3N ua.test.group.3NN




#make buffer for training and test feature file
../../tools/make_ugroup_buffer ua.base.group.3NN buffer.base.svdpp 

../../tools/make_ugroup_buffer test_feature.base buffer.test.svdpp 

# training for 40 rounds
../../svd_feature Recommodation.conf num_round=100

# write out prediction from 0040.model
../../svd_feature_infer Recommodation.conf pred=100 name_pred=pred.txt

python feature/evaluation.py pred.txt 5

