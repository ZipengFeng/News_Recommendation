#-*- coding:utf-8 -*-
'''
For evaluation of the recommodation
'''

import numpy as np
import json
import random
random.seed(2017)

def precision_k(groundtruth_path, newsID_index_path, userID_dict_path, test_userID_path, test_news2keywords_path, pred_path, k):
    groundtruth = open(groundtruth_path, 'r')
    pred_results = open(pred_path, 'r')
    with open(newsID_index_path, 'r') as f:
	newsID_index = json.load(fp=f)
    with open(test_news2keywords_path, 'r') as f:
	test_news2keywords = json.load(fp=f)

    test_news_index = []
    with open(userID_dict_path, 'r') as f:
        userID_dict = json.load(fp=f)
 
    for news in test_news2keywords.keys():		#record the sequential index of test news
	test_news_index.append(newsID_index[news])
    test_news_index = np.array(test_news_index)
    num_test_news = len(test_news2keywords)		#num of test news

    userID_groundtruthList = {}				#{user:groundtruth_news_index}
    for line in groundtruth.readlines():
	line = line.strip().split('\t')
	if userID_groundtruthList.has_key(int(line[0])):
	    
	    userID_groundtruthList[int(line[0])].add(newsID_index[line[1]])
	else:
	    userID_groundtruthList[int(line[0])] = set([])
	    userID_groundtruthList[int(line[0])].add(newsID_index[line[1]])

    with open(test_userID_path, 'r') as f:
	test_userID = []
	for line in f.readlines():

	    test_userID.append(int(line.strip()))
    acc = 0

    user_pred = []
    i = 0	
    for score in pred_results.readlines():
	user_pred.append(float(score.strip()))
	if len(user_pred) == num_test_news:
            user_predicted_newsIndex = set(test_news_index[(np.argsort(user_pred)[::-1][:k])])
	    acc += len(user_predicted_newsIndex & userID_groundtruthList[test_userID[i]])/float(k)
	    #print len(user_predicted_newsIndex  & userID_groundtruthList[test_userID[i]])
	    i += 1
	    user_pred = []
    acc /= float(len(test_userID))

    print 'precison@%d is %.4f%%'%(k, acc*100)
    	     
if __name__ =='__main__':
    
    groundtruth_path = './test_feature_groundtruth.txt'
    newsID_index_path = './newsID_index.json'
    userID_dict_path = 'userid_dict.json'
    test_userID_path = 'test_userID.txt'
    test_news2keywords_path = './test_newsID2keywords.json' 
    pred_path = './pred.txt' 
    k = 10
    precision_k(groundtruth_path, newsID_index_path, userID_dict_path, test_userID_path, test_news2keywords_path, pred_path, k)


		
