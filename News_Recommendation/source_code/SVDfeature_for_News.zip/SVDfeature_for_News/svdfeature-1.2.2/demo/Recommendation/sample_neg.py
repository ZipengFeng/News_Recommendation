import random
import sys
random.seed(2017)
def sample_neg(inputfile_path, outputfile_path, num_neg):
    grouped_data = open(inputfile_path,'r')
    withneg_data = open(outputfile_path,'w')
    grouped_data = list(grouped_data.readlines())

    user_to_newsID = {}
    i = 1
    for line in grouped_data:
	print 'collecting %d lines...'%i
	i += 1
	if user_to_newsID.has_key(line.split('\t')[0]):
	    user_to_newsID[line.split('\t')[0]].add(line.split('\t')[1])
	else:
	    user_to_newsID[line.split('\t')[0]] = set([line.split('\t')[1]])
    num_features = len(grouped_data)
    i = 1
    for line in grouped_data:
	print 'processing %d line...'%i
	i += 1
	
	userID = line.split('\t')[0]
	
	num_of_userfeature = int(line.split('\t')[4])
	user_feature = line.split('\t')[6:(6+num_of_userfeature)]
	withneg_data.writelines(line)
	samples = {}
	for j in range(num_neg):
	    while True:
	        lineindex = random.randint(0,num_features-1)
	        #print grouped_data[lineindex].split('\t')
	        if grouped_data[lineindex].split('\t')[1] not in user_to_newsID[userID] and (not samples.has_key(lineindex)):
		    break
	    samples[lineindex]=1
	    attr = (grouped_data[lineindex]).strip().split('\t')
	   
	    
	    neg_num_of_itemfea = int(attr[5])
	    item_feature = attr[-1*neg_num_of_itemfea:]
	      				
	    withneg_data.write(userID+'\t'+attr[1]+'\t0\t0\t'+str(num_of_userfeature)+'\t'+str(neg_num_of_itemfea))
	    for fea in user_feature:
		withneg_data.write('\t'+fea)
	    for term in item_feature:

	        withneg_data.write('\t'+term)
	    withneg_data.write('\n')



if __name__ == '__main__':
    input_no_neg_path = sys.argv[1]
    output_with_neg_path = sys.argv[2]
    neg_samples = int(sys.argv[3])
    sample_neg(input_no_neg_path, output_with_neg_path, neg_samples)
