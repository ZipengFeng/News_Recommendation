import sys

def base_to_feature(base_path, output_path):		#delete the userID and newsID in first 2 column
    outputfile = open(output_path, 'w')
    with open(base_path, 'r') as f:
	for line in f.readlines():
	    split_line = line.strip().split('\t')[2:]
	    newline = ''
	    for item in split_line[:-1]:
		
		newline += (item+'\t')
	    newline += split_line[-1]+'\n'
	    outputfile.writelines(newline)
    outputfile.close()



if __name__ == '__main__':
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    base_to_feature(input_path, output_path)

