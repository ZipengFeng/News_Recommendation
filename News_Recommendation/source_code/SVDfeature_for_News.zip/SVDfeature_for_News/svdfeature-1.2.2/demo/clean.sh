#!/bin/bash

# clean all the trace of demo
rm -rf pred.txt *.svdpp *.group *.order *.shuffle *.model *.*feature *.*buffer

