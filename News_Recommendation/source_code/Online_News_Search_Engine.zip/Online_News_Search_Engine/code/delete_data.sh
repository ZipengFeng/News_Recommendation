cd ../data/news/sorted/
ls | xargs rm -f
cd ../souhu
ls | xargs rm -f
cd ../cankao
ls | xargs rm -f
cd ../tencent
ls | xargs rm -f
cd ../netease
ls | xargs rm -f
